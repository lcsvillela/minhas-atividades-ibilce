public interface InterfaceTime{


	public void setInfos(int golsFeitos, int golsContra, int vitorias, int derrotas, int empates);
	public int getGolsFeitos();
	public int getGolsContra();
	
}
