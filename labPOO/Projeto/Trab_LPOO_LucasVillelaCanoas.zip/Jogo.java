public class Jogo{

	int golsFeitos;
	String adversario;
	int golsAdversario;

	public Jogo(int golsFeitos, String adversario, int golsAdversario){
	
		this.golsFeitos = golsFeitos;
		this.adversario = adversario;
		this.golsAdversario = golsAdversario;
	}
}
