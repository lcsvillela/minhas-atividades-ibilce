public interface InterfaceEmpregado {

		
	public double getSalario ();

	public String getNome();
	
	public int getHorasTrabalhadas();
	
	public int getID();
}	
